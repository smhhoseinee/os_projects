
1.compile main.c

2.run main.c

3.enter the directory path: (ex: '../tempFolder')

4.outputs:

    Total number of files
    Number of each file type:
    *.txt: 237
    *.pdf: 189
    *.jpg: 320
    *.png: 277
    largest file size
    File with the smallest size
    Size
    Size of the folder