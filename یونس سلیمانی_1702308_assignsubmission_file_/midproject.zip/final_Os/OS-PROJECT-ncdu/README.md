# OS-PROJECT-ncdu
a ncdu simulator project with simple GUI
